import Header from "./components/Header";
import Hero from "./sections/Hero";
import Sobre from "./sections/Sobre";

export default function HomePage(){

  return(

<>
<Header/>
<Hero/>
<Sobre/>
</>

  )
}